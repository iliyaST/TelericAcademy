﻿
namespace WarMachines.Common.Enum
{
    public enum MachineType
    {
        Tank,
        Fighter
    }
}
