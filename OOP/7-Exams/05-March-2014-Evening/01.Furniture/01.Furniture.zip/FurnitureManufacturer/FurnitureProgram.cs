﻿namespace FurnitureManufacturer
{
    using Engine;

    public class FurnitureProgram
    {
        public static void Main()
        {
            FurnitureManufacturerEngine.Instance.Start();
        }
    }
}
